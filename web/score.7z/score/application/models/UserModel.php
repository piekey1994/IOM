<?php
/**
 * Created by PhpStorm.
 * User: szu
 * Date: 2018/5/18
 * Time: 16:10
 */
class UserModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database($this->config->item('dbname'));
    }
    public function registerUser($username)
    {
        $data = array(
            'name' => $username,
        );
        $this->db->insert('user', $data);
        return $this->db->insert_id();
    }
}