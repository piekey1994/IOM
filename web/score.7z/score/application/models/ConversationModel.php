<?php
/**
 * Created by PhpStorm.
 * User: szu
 * Date: 2018/5/18
 * Time: 16:19
 */
class ConversationModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database($this->config->item('dbname'));
    }
    public function getConv($num)
    {
        $data = array(
            'id' => $num+1,
        );
        $query = $this->db->get_where('conversation', $data);
        return $query->row();
    }
    public function addScore($uid,$cid,$score)
    {
        $data = array(
            'uid' => $uid,
            'cid' => $cid,
            'score' => $score
        );
        return $this->db->insert($this->config->item('scoretype'), $data);
    }
    public function getAllConv()
    {
        $query = $this->db->query("SELECT question,answer,id FROM conversation");
        return $query->result_array();
    }
}