<?php
/**
 * Created by PhpStorm.
 * User: szu
 * Date: 2018/5/18
 * Time: 14:45
 */
class Home extends CI_Controller {

    public function index()
    {
        $this->load->library('session');
        $name = $this->input->post('name');
        if(!$name)
            $this->load->view('home.html');
        else
        {
            $this->load->model('UserModel');
            $uid=$this->UserModel->registerUser($name);
            $this->load->model('ConversationModel');
            $allConv=$this->ConversationModel->getAllConv();
            shuffle($allConv);
            $this->session->set_userdata('all', $allConv);
            $this->session->set_userdata('name', $name);
            $this->session->set_userdata('uid', $uid);
            $this->session->unset_userdata('num');
            header('location:/'.$this->config->item('webname').'/Evaluate');
        }
    }
}