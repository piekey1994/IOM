<?php
/**
 * Created by PhpStorm.
 * User: szu
 * Date: 2018/5/18
 * Time: 15:20
 */
class Evaluate extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('ConversationModel');
        date_default_timezone_set('PRC');
    }

    public function index()
    {
        $name = $this->session->userdata('name');

        if(!$name)
            header('location:/'.$this->config->item('webname').'/home');
        else
        {
            $date['name']=$name;
            $this->load->view('tutorial.html',$date);
        }
    }
    public function start()
    {
        $name = $this->session->userdata('name');
        $allConv=$this->session->userdata('all');
        $num = $this->session->userdata('num');
        if(!$name)
            header('location:/'.$this->config->item('webname').'/home');
        else
        {
            if (!$num)
            {
                $this->session->set_userdata('begintime', strtotime(date("Y-m-d H:i:s")));
                $this->session->set_userdata('num', 1);
                $num=1;
            }
            $conv=$allConv[$num-1];
            $date=array(
                'sum'=>count($allConv),
                'num' =>$num,
                'name' => $name,
                'question' => $conv['question'],
                'answer' => $conv['answer'],
                'webname' => $this->config->item('webname')
            );
            $this->load->view('eval.html',$date);
        }
    }
    public function score()
    {
        $score=$this->input->get('score');
        if($score!=null)
        {
            $num = $this->session->userdata('num');
            $uid = $this->session->userdata('uid');
            $allConv=$this->session->userdata('all');
            if ($num)
            {
                $conv=$allConv[$num-1];
                $cid=$conv['id'];
                $this->ConversationModel->addScore($uid,$cid,$score);
                if($num==count($allConv))
                {
                    $begintime = $this->session->userdata('begintime');
                    $this->session->unset_userdata('num');
                    $this->session->unset_userdata('name');
                    $usetime=strtotime(date("Y-m-d H:i:s"))-$begintime;
                    $usemin=$usetime/60;
                    echo '2:'.$usemin;
                }
                else
                {
                    $this->session->set_userdata('num', $num+1);
                    echo '1:ok';
                }


            }
        }
        else
        {
            echo 'no score';
        }
    }
}